public enum ParticipationStatus {
    CONFIRMED, CANCELED
}
